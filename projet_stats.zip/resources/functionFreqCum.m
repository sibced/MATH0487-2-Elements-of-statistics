function frequ = functionFreqCum(ech, y)

m = ech < y;

frequ = mean(m);

end