pop = population(readtable('data.csv'),39)


hist(table2array(pop(:,7)))